import { ref } from 'vue';
import { useToast } from './useToast';
import { musicApi } from '../api/music.js';
import { authApi } from '../api/auth.js';
import { extractErrorMessage } from '../utils/errors.js';

export function useSearchLogic(emit) {
    const { success, error } = useToast();

    const platform = ref('netease');
    const keyword = ref('');
    const songs = ref([]);
    const albums = ref([]);
    const loading = ref(false);
    const listMode = ref('search'); // 'search' | 'playlist' | 'albumSearch' | 'album'
    const searchType = ref('song'); // 'song' | 'album'
    const isAdminMode = ref(false);

    // 存储原始的管理员指令
    const adminCommand = ref('');

    const handleAdminCommand = async (pwd) => {
        try {
            await authApi.adminCommand(pwd, adminCommand.value);
            success('ADMIN COMMAND EXECUTED');
            emit('close');
        } catch (e) {
            console.error('Admin command failed:', e);
            error(extractErrorMessage(e, 'ACCESS DENIED OR COMMAND FAILED'));
        } finally {
            isAdminMode.value = false;
            keyword.value = '';
            adminCommand.value = '';
        }
    };

    const doSearch = async () => {
        const val = keyword.value.trim();
        if (!val) return;

        // 1. 管理员密码输入模式
        if (isAdminMode.value) {
            await handleAdminCommand(val);
            return;
        }

        if (val.startsWith('//')) {
            isAdminMode.value = true;
            adminCommand.value = val; // 保存完整指令
            keyword.value = ''; // 清空输入框，准备输入密码
            return;
        }


        // 3. 普通搜索
        listMode.value = searchType.value === 'album' && platform.value === 'netease' ? 'albumSearch' : 'search';
        loading.value = true;
        songs.value = [];
        albums.value = [];
        try {
            if (searchType.value === 'album' && platform.value === 'netease') {
                albums.value = await musicApi.searchNeteaseAlbums(val);
            } else {
                const data = await musicApi.search(platform.value, val);
                songs.value = data;
                const missingCoverCount = Array.isArray(data)
                    ? data.filter(song => !song?.coverUrl || !String(song.coverUrl).trim()).length
                    : 0;
                if (missingCoverCount > 0) {
                    console.warn(`[search] ${platform.value} results missing coverUrl: ${missingCoverCount}/${data.length}`);
                }
            }
        } catch (e) {
            console.error('Search failed:', e);
            error(extractErrorMessage(e, 'Search Failed'));
        } finally {
            loading.value = false;
        }
    };

    return {
        platform,
        keyword,
        songs,
        albums,
        loading,
        listMode,
        searchType,
        isAdminMode,
        doSearch
    };
}
